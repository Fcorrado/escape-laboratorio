#ifndef __DETECTOR_PERSONAJES_H__
#define __DETECTOR_PERSONAJES_H__

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

void detector_de_personajes(char* personaje_detectado);


#endif /* __DETECTOR_PERSONAJES_H__ */