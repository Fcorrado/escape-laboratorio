#ifndef __INTERACCION_USUARIO_H__
#define __INTERACCION_USUARIO__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void bienvenida();

void obtener_mas_informacion();

void mostrar_nombre_personaje(char tipo_personaje);

void mostrar_informacion_del_juego();


#endif /* __INTERACCION_USUARIO_H__ */